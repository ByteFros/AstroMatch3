import { title } from "@/components/primitives";

export default function ProfilePage() {
  return (
    <div>
      <h1 className={title()}>ProfilePage</h1>
    </div>
  );
}
